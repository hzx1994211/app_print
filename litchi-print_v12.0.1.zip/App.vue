<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	page{
		height: 100%;
		width: 100%;
		margin: 0;
		padding: 10rpx;
	}
	
	.uni-flex{
		display: flex;
	}
	.uni-row{
		flex-direction: row;
	}
	.flex-item{
		flex: 1;
	}
</style>
